package com.jsp.jst_ticket_booking_spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JstTicketBookingSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
